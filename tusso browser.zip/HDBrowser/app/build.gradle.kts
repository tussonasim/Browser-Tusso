plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// !! Put the newest GeckoView version from https://maven.mozilla.org/?prefix=maven2/org/mozilla/geckoview/geckoview/
val geckoVersion = "REPLACE_WITH_LATEST"

android {
    namespace = "com.example.hdbrowser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.hdbrowser"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "2.0"
        ndk { abiFilters += listOf("arm64-v8a") }   // keeps APK size down
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("org.mozilla.geckoview:geckoview:$geckoVersion")
}
