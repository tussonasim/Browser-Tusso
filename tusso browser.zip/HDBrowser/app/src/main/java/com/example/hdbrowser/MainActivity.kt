package com.example.hdbrowser

import android.Manifest
import android.app.DownloadManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.provider.MediaStore
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.TextUtils
import android.util.Rational
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.URLUtil
import java.io.File
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import org.mozilla.geckoview.*

class MainActivity : AppCompatActivity() {

    private class BrowserTab(val view: GeckoView, val session: GeckoSession, val label: TextView) {
        var url = ""
        var title = ""
        var canBack = false
        var canForward = false
        var desktop = false
        var dnsAttempt = 0
    }

    // Auto DNS fallback list (DNS-over-HTTPS), tried one by one when a site fails to resolve/connect
    private val dohServers = listOf(
        "https://cloudflare-dns.com/dns-query",
        "https://dns.google/dns-query"
    )
    private val ublockId = "uBlock0@raymondhill.net"
    private val ublockUrl = "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi"
    private val homeUrl = "https://www.google.com"

    private lateinit var store: Store
    private lateinit var root: View
    private lateinit var tabBar: View
    private lateinit var toolbar: View
    private lateinit var urlBar: EditText
    private lateinit var btnStar: Button
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var tabContainer: LinearLayout
    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null
    private var fullscreen = false

    companion object { private var runtime: GeckoRuntime? = null }

    private fun rt(): GeckoRuntime = runtime ?: GeckoRuntime.create(
        this,
        GeckoRuntimeSettings.Builder()
            .configFilePath(writeProxyConfig())
            .contentBlocking(
                ContentBlocking.Settings.Builder()
                    .antiTracking(ContentBlocking.AntiTracking.STRICT) // ads + trackers
                    .build()
            )
            .build()
    ).also { runtime = it; setupAdBlocker(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        AppCompatDelegate.setDefaultNightMode(
            if (store.dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        tabBar = findViewById(R.id.tabBar)
        toolbar = findViewById(R.id.toolbar)
        urlBar = findViewById(R.id.urlBar)
        btnStar = findViewById(R.id.btnStar)
        progress = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        tabContainer = findViewById(R.id.tabContainer)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener { current?.let { if (it.canBack) it.session.goBack() } }
        findViewById<Button>(R.id.btnForward).setOnClickListener { current?.let { if (it.canForward) it.session.goForward() } }
        findViewById<Button>(R.id.btnReload).setOnClickListener { current?.session?.reload() }
        findViewById<Button>(R.id.btnHome).setOnClickListener { current?.session?.loadUri(homeUrl) }
        findViewById<Button>(R.id.btnNewTab).setOnClickListener { openTab(homeUrl) }
        btnStar.setOnClickListener { addBookmark() }
        findViewById<Button>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        urlBar.setOnEditorActionListener { _, actionId, event ->
            val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                current?.let { it.dnsAttempt = 0; it.session.loadUri(toUrl(urlBar.text.toString())) }
                hideKeyboard()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val tab = current
                when {
                    fullscreen -> tab?.session?.exitFullScreen()
                    tab != null && tab.canBack -> tab.session.goBack()
                    tab != null && tabs.size > 1 -> closeTab(tab)
                    else -> finish()
                }
            }
        })

        rt()
        openTab(homeUrl)
        applyTheme()
    }

    // ------------------------------------------------------------ ad blocker

    /** Installs uBlock Origin (from addons.mozilla.org) once. Also blocks YouTube ads (best effort). */
    private fun setupAdBlocker(r: GeckoRuntime) {
        val ctl = r.webExtensionController
        ctl.setPromptDelegate(object : WebExtensionController.PromptDelegate {
            override fun onInstallPrompt(extension: WebExtension): GeckoResult<AllowOrDeny>? =
                GeckoResult.fromValue(AllowOrDeny.ALLOW)
        })
        ctl.list().accept { list ->
            if (list?.none { it.id == ublockId } != false) {
                ctl.install(ublockUrl, WebExtensionController.INSTALLATION_METHOD_MANAGER)
            }
        }
    }

    // ------------------------------------------------------------- auto DNS

    private fun applyDoh(stage: Int) {
        val s = rt().settings
        s.setTrustedRecursiveResolverUri(dohServers[stage])
        s.setTrustedRecursiveResolverMode(GeckoRuntimeSettings.TRR_MODE_FIRST)
    }

    private fun handleLoadError(tab: BrowserTab, uri: String, error: WebRequestError) {
        val network = error.code == WebRequestError.ERROR_UNKNOWN_HOST ||
            error.code == WebRequestError.ERROR_CONNECTION_REFUSED ||
            error.code == WebRequestError.ERROR_NET_RESET ||
            error.code == WebRequestError.ERROR_NET_TIMEOUT
        if (!network) return
        runOnUiThread {
            if (tab.dnsAttempt < dohServers.size) {
                applyDoh(tab.dnsAttempt)
                tab.dnsAttempt++
                toast("Site not loading — switching DNS (${tab.dnsAttempt}/${dohServers.size})")
                tab.session.loadUri(uri)
            } else if (tab === current) {
                tab.dnsAttempt = 0
                AlertDialog.Builder(this)
                    .setTitle("Still blocked")
                    .setMessage("Changing DNS did not help. This site may need a VPN. Open VPN settings?")
                    .setPositiveButton("VPN settings") { _, _ ->
                        startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                    }
                    .setNeutralButton("Use Tor / Proxy") { _, _ -> showProxyDialog() }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }

    // ------------------------------------------------------------ Tor / proxy

    /** Gecko reads proxy prefs from this file at startup, so changing proxy = app restart. */
    private fun writeProxyConfig(): String {
        val sb = StringBuilder("prefs:\n")
        when (store.proxyType) {
            1, 2 -> {
                val host = if (store.proxyType == 1) "127.0.0.1" else store.proxyHost
                val port = if (store.proxyType == 1) 9050 else store.proxyPort
                sb.append("  network.proxy.type: 1\n")
                sb.append("  network.proxy.socks: \"$host\"\n")
                sb.append("  network.proxy.socks_port: $port\n")
                sb.append("  network.proxy.socks_version: 5\n")
                sb.append("  network.proxy.socks_remote_dns: true\n")
            }
            3 -> {
                sb.append("  network.proxy.type: 1\n")
                sb.append("  network.proxy.http: \"${store.proxyHost}\"\n")
                sb.append("  network.proxy.http_port: ${store.proxyPort}\n")
                sb.append("  network.proxy.ssl: \"${store.proxyHost}\"\n")
                sb.append("  network.proxy.ssl_port: ${store.proxyPort}\n")
            }
            else -> sb.append("  network.proxy.type: 0\n")
        }
        val f = File(filesDir, "geckoview-config.yaml")
        f.writeText(sb.toString())
        return f.absolutePath
    }

    private fun showProxyDialog() {
        val names = arrayOf("Off", "Tor (needs Orbot app)", "Custom SOCKS5 proxy", "Custom HTTP proxy")
        AlertDialog.Builder(this)
            .setTitle("Proxy / Tor")
            .setSingleChoiceItems(names, store.proxyType) { d, which ->
                d.dismiss()
                when (which) {
                    0 -> applyProxy(0)
                    1 -> {
                        val orbot = packageManager.getLaunchIntentForPackage("org.torproject.android")
                        if (orbot == null) {
                            toast("Install Orbot first (F-Droid / Play Store), start it, then choose Tor again")
                            startActivity(Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://play.google.com/store/apps/details?id=org.torproject.android")))
                        } else {
                            toast("Start Orbot (tap Start) — the browser will restart")
                            startActivity(orbot)
                            applyProxy(1)
                        }
                    }
                    else -> askProxyAddress(which)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askProxyAddress(type: Int) {
        val input = EditText(this).apply {
            hint = "host:port  (e.g. 192.168.1.5:1080)"
            setText(if (store.proxyHost.isNotBlank()) "${store.proxyHost}:${store.proxyPort}" else "")
        }
        AlertDialog.Builder(this)
            .setTitle(if (type == 2) "SOCKS5 proxy" else "HTTP proxy")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val parts = input.text.toString().trim().split(":")
                val port = parts.getOrNull(1)?.toIntOrNull()
                if (parts.size != 2 || parts[0].isBlank() || port == null) {
                    toast("Format must be host:port")
                } else {
                    store.proxyHost = parts[0]
                    store.proxyPort = port
                    applyProxy(type)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun applyProxy(type: Int) {
        store.proxyType = type
        toast("Restarting browser to apply proxy…")
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        window.decorView.postDelayed({
            startActivity(Intent.makeRestartActivityTask(launch!!.component))
            Runtime.getRuntime().exit(0)
        }, 800)
    }

    // ---------------------------------------------------------------- tabs

    private fun openTab(url: String): GeckoSession {
        val view = GeckoView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val session = GeckoSession()
        session.open(rt())
        view.setSession(session)

        val label = TextView(this).apply {
            text = "New Tab"
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(dp(170), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val tab = BrowserTab(view, session, label)
        label.setOnClickListener { select(tab) }
        label.setOnLongClickListener { closeTab(tab); true }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                s: GeckoSession, u: String?, perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                tab.url = u ?: ""
                if (tab === current) runOnUiThread { urlBar.setText(tab.url); updateStar() }
            }
            override fun onCanGoBack(s: GeckoSession, can: Boolean) { tab.canBack = can }
            override fun onCanGoForward(s: GeckoSession, can: Boolean) { tab.canForward = can }
            override fun onNewSession(s: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                runOnUiThread { openTab(uri) }
                return null
            }
            override fun onLoadError(s: GeckoSession, uri: String?, error: WebRequestError): GeckoResult<String>? {
                if (uri != null) handleLoadError(tab, uri, error)
                return null
            }
        }
        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onProgressChange(s: GeckoSession, p: Int) {
                if (tab === current) runOnUiThread {
                    progress.progress = p
                    progress.visibility = if (p < 100) View.VISIBLE else View.GONE
                }
            }
            override fun onPageStop(s: GeckoSession, success: Boolean) {
                if (success && tab.url.isNotBlank() && tab.url != "about:blank") {
                    tab.dnsAttempt = 0
                    store.addHistory(Entry(tab.title.ifBlank { tab.url }, tab.url))
                }
            }
        }
        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(s: GeckoSession, title: String?) {
                tab.title = title ?: ""
                if (tab.title.isNotBlank()) runOnUiThread { label.text = tab.title }
            }
            override fun onExternalResponse(s: GeckoSession, response: WebResponse) {
                saveResponse(response)
            }
            override fun onContextMenu(
                s: GeckoSession, x: Int, y: Int, element: GeckoSession.ContentDelegate.ContextElement
            ) {
                val target = element.srcUri ?: element.linkUri ?: return
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(target.take(80))
                        .setItems(arrayOf("Download", "Open in new tab")) { _, i ->
                            if (i == 0) startDownload(target, null, null) else openTab(target)
                        }
                        .show()
                }
            }
            override fun onFullScreen(s: GeckoSession, fs: Boolean) {
                fullscreen = fs
                runOnUiThread {
                    val v = if (fs) View.GONE else View.VISIBLE
                    tabBar.visibility = v
                    toolbar.visibility = v
                }
            }
        }

        tabs.add(tab)
        webContainer.addView(view)
        tabContainer.addView(label)
        select(tab)
        session.loadUri(url)
        return session
    }

    private fun select(tab: BrowserTab) {
        current = tab
        for (t in tabs) t.view.visibility = if (t === tab) View.VISIBLE else View.GONE
        urlBar.setText(tab.url)
        progress.visibility = View.GONE
        styleTabs()
        updateStar()
    }

    private fun closeTab(tab: BrowserTab) {
        if (tabs.size == 1) {
            tab.session.loadUri(homeUrl)
            return
        }
        val index = tabs.indexOf(tab)
        tabs.remove(tab)
        webContainer.removeView(tab.view)
        tabContainer.removeView(tab.label)
        tab.session.close()
        select(tabs[minOf(index, tabs.size - 1)])
    }

    // ----------------------------------------------------------- menu & lists

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Add bookmark")
        pm.menu.add(0, 2, 1, "Bookmarks")
        pm.menu.add(0, 3, 2, "History")
        pm.menu.add(0, 4, 3, "Downloads")
        pm.menu.add(0, 5, 4, "Desktop site").apply { isCheckable = true; isChecked = current?.desktop == true }
        pm.menu.add(0, 6, 5, "Dark mode").apply { isCheckable = true; isChecked = store.dark }
        pm.menu.add(0, 7, 6, "Clear history")
        pm.menu.add(0, 8, 7, "Picture-in-Picture")
        pm.menu.add(0, 10, 8, "Proxy / Tor")
        pm.menu.add(0, 9, 9, "About")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> addBookmark()
                2 -> showList("Bookmarks", store.bookmarks()) { l -> store.saveBookmarks(l) }
                3 -> showList("History", store.history()) { l -> store.saveHistory(l) }
                4 -> startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                5 -> toggleDesktop()
                6 -> toggleDark()
                7 -> { store.saveHistory(emptyList()); toast("History cleared") }
                8 -> enterPip()
                9 -> showAbout()
                10 -> showProxyDialog()
            }
            true
        }
        pm.show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("About")
            .setMessage("HD Browser v2.0\n\nDeveloped by TUSSO\n\nEngine: Mozilla Gecko")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun addBookmark() {
        val tab = current ?: return
        if (tab.url.isBlank()) return
        val added = store.addBookmark(Entry(tab.title.ifBlank { tab.url }, tab.url))
        toast(if (added) "Bookmark added" else "Already bookmarked")
        updateStar()
    }

    private fun updateStar() {
        btnStar.text = if (store.isBookmarked(current?.url)) "★" else "☆"
    }

    private fun showList(title: String, items: MutableList<Entry>, save: (List<Entry>) -> Unit) {
        if (items.isEmpty()) { toast("$title is empty"); return }
        val labels = items.map { it.title.ifBlank { it.url } }.toMutableList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val dialog = AlertDialog.Builder(this)
            .setTitle("$title (long-press = delete)")
            .setAdapter(adapter, null)
            .setNegativeButton("Close", null)
            .create()
        dialog.show()
        dialog.listView.setOnItemClickListener { _, _, i, _ ->
            current?.session?.loadUri(items[i].url)
            dialog.dismiss()
        }
        dialog.listView.setOnItemLongClickListener { _, _, i, _ ->
            items.removeAt(i); labels.removeAt(i)
            adapter.notifyDataSetChanged()
            save(items); updateStar()
            true
        }
    }

    // -------------------------------------------------------------- download

    /** Saves the stream Gecko hands us (keeps cookies/login) into the public Downloads folder. */
    private fun saveResponse(response: WebResponse) {
        val h = response.headers.entries.associate { it.key.lowercase() to it.value }
        val mime = h["content-type"]?.substringBefore(";")?.trim()
        val name = URLUtil.guessFileName(response.uri, h["content-disposition"], mime)
        val body = response.body
        if (body == null) { runOnUiThread { toast("Download failed") }; return }
        runOnUiThread { toast("Downloading: $name") }
        Thread {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    mime?.let { put(MediaStore.Downloads.MIME_TYPE, it) }
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
                contentResolver.openOutputStream(uri)!!.use { out -> body.use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                runOnUiThread { toast("Saved to Downloads: $name"); notifyDone(name, uri, mime) }
            } catch (e: Exception) {
                runOnUiThread { toast("Download failed") }
            }
        }.start()
    }

    private fun notifyDone(name: String, uri: Uri, mime: String?) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("dl", "Downloads", NotificationManager.IMPORTANCE_DEFAULT))
        val open = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime ?: "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            name.hashCode(),
            Notification.Builder(this, "dl")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(name).setContentText("Download complete")
                .setContentIntent(pi).setAutoCancel(true).build()
        )
    }

    private fun startDownload(url: String, disposition: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, disposition, mime)
            val req = DownloadManager.Request(Uri.parse(url)).apply {
                mime?.let { setMimeType(it) }
                setTitle(name)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading: $name")
        } catch (e: Exception) {
            toast("Download failed")
        }
    }

    // ------------------------------------------------------ Picture-in-Picture

    private fun isYoutube(): Boolean {
        val h = Uri.parse(current?.url ?: "").host ?: return false
        return h.contains("youtube.com") || h.contains("youtu.be")
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        }
    }

    /** Pressing Home while watching YouTube -> automatic PiP. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isYoutube()) enterPip()
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(inPip, newConfig)
        val v = if (inPip) View.GONE else View.VISIBLE
        tabBar.visibility = v
        toolbar.visibility = v
    }

    // ------------------------------------------------------------- dark mode

    private fun toggleDark() {
        store.dark = !store.dark
        AppCompatDelegate.setDefaultNightMode(
            if (store.dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        applyTheme()
    }

    private fun applyTheme() {
        val dark = store.dark
        rt().settings.setPreferredColorScheme(
            if (dark) GeckoRuntimeSettings.COLOR_SCHEME_DARK else GeckoRuntimeSettings.COLOR_SCHEME_LIGHT
        )
        root.setBackgroundColor(if (dark) 0xFF121212.toInt() else Color.WHITE)
        val bar = if (dark) 0xFF1F1F1F.toInt() else 0xFFECEFF1.toInt()
        tabBar.setBackgroundColor(bar)
        toolbar.setBackgroundColor(bar)
        urlBar.setTextColor(if (dark) Color.WHITE else Color.BLACK)
        urlBar.setHintTextColor(Color.GRAY)
        styleTabs()
    }

    private fun styleTabs() {
        val dark = store.dark
        val bg = if (dark) 0xFF121212.toInt() else Color.WHITE
        val fg = if (dark) Color.WHITE else Color.BLACK
        for (t in tabs) {
            t.label.setTextColor(fg)
            t.label.setBackgroundColor(if (t === current) bg else Color.TRANSPARENT)
        }
    }

    // ----------------------------------------------------------------- misc

    private fun toggleDesktop() {
        val tab = current ?: return
        tab.desktop = !tab.desktop
        tab.session.settings.userAgentMode =
            if (tab.desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        tab.session.settings.viewportMode =
            if (tab.desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        tab.session.reload()
    }

    private fun toUrl(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") -> "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() { tabs.forEach { it.session.close() }; super.onDestroy() }
}
